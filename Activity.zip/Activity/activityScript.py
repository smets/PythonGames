from livewires import games, color
import random
games.init(screen_width = 640, screen_height = 480, fps = 50)

class Apple(games.Sprite):
    IMAGE = games.load_image("apple.png")
    def __init__(self, x, y):
        super(Apple, self).__init__(x = x, y = y,
                                    image = Apple.IMAGE)
        self.dy = 1
    def update(self):
        super(Apple, self).update()
        if self.y >= games.screen.height:
            self.end_game()
    def end_game(self):
        end_message = games.Message(value = "Game Over",
                                    size = 90,
                                    color = color.red,
                                    x = games.screen.width/2,
                                    y = games.screen.height/2,
                                    lifetime = 2 * games.screen.fps,
                                    after_death = games.screen.quit)
        games.screen.add(end_message)

        
class Bucket(games.Sprite):
    IMAGE = games.load_image("bucket.png")
    def __init__(self, oddsOfAppleDrop):
        super(Bucket, self).__init__(x = games.screen.width/2,
                                     y = games.screen.height - 35,
                                     image = Bucket.IMAGE)
        self.scoreText = games.Text(value = "SCORE: ",
                                    left = 10, top = 20,
                                    color = color.red,
                                    size = 30)
        self.scoreVal = games.Text(value = 0,
                                   left = self.scoreText.right + 10,
                                   top = 20, color = color.red,
                                   size = 30)
        self.oddsOfAppleDrop = oddsOfAppleDrop
        games.screen.add(self)
        games.screen.add(self.scoreText)
        games.screen.add(self.scoreVal)
    def update(self):
        super(Bucket, self).update()
        self.x = games.mouse.x
        if random.randint(0,self.oddsOfAppleDrop) == 1:
            apple = Apple(x = random.randint(25, 615), y = 0)
            games.screen.add(apple)
        for sprite in self.overlapping_sprites:
            sprite.destroy()
            self.scoreVal.value += 10
        
def main():
    back = games.load_image("tree.jpeg",transparent = False)
    games.screen.set_background(back)
    bucket = Bucket(oddsOfAppleDrop = 90)

    games.screen.mainloop()

main()
